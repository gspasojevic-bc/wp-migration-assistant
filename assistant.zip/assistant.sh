npm install
node assistant.js